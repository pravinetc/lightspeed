import json
import logging
import boto3
import botocore
from boto3.dynamodb.conditions import Key
import math

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def first_n_digits(num, n):
    return num // 10 ** (int(math.log(num, 10)) - n + 1)
    
def get_postcode(postcode):
    
    print("In get_postcode")
    for elements in postcode:
        input_postcode = elements
        break
    
     
    print(input_postcode)

    #validate postcode 
    if  input_postcode.isnumeric():
        input_postcode = int(input_postcode)
        print("Post code validated")
    else:
        return ("Incorrect PostCode")
        
    print('retrieved postcode = {0}'.format(input_postcode))
    
    # #connect to dynamodb 
    dynamodb = boto3.resource("dynamodb")

    table = dynamodb.Table('postcode_lookup')
    
    #set the leading digit of postcode to be the table key 
    
    if input_postcode < 1000:
        table_key = 0 
    else:
        table_key = first_n_digits(input_postcode,1)
    
    
    logger.info('Input postcode received = {0}'.format(input_postcode))
    logger.info('Processing with key = {0}'.format(table_key))
    try:
        #response = table.get_item(Key={'postcode_init': int(table_key)})
        response = table.query(KeyConditionExpression=Key('postcode_init').eq(table_key))
    except Exception as e:
        #print(e.response['Error']['Message'])
        print(e)
    else:
        print(f"retrived item = {response['Items'][0]['NearestOffice']}")
        return response['Items'][0]['NearestOffice']


def lambda_handler(event, context):
    # TODO implement
    print(f"event details = {event}")
    # logger.info('Testing line in log')
    output = get_postcode({event["queryStringParameters"]["postcode"]})
    #print(f"output retrived from dynamodb table = {output}")
    return {
        'statusCode': 200,
        #'body': json.dumps(f'Hello from Lambda! - {type(event["queryStringParameters"]["postcode"])}')
        'body': json.dumps(f'Hello from Lambda! - {output}')
    }
